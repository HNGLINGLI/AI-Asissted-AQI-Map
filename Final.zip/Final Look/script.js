const chatbotToggler = document.querySelector(".chatbot-toggler");
const closeBtn = document.querySelector(".close-btn");
const chatbox = document.querySelector(".chatbox");
const chatInput = document.querySelector(".chat-input textarea");
const sendChatBtn = document.querySelector("#send-btn"); 
const micBtn = document.getElementById("mic-btn");
const copyright = document.querySelector('.copyright'); // Select your copyright element

let userMessage = null; // Variable to store user's message
const inputInitHeight = chatInput.scrollHeight;

// API configuration
const API_KEY = "Your-api-key"; // Your API key here
const API_URL = `https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent?key=${API_KEY}`;

// Speech Recognition setup
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const recognition = new SpeechRecognition();
recognition.lang = 'en-US'; // Set language
recognition.interimResults = false; // Finalize each speech chunk

// Function to create chat message elements
const createChatLi = (message, className) => {
  const chatLi = document.createElement("li");
  chatLi.classList.add("chat", `${className}`);
  let chatContent = className === "outgoing" ? `<p></p>` : `<span class="material-symbols-outlined">smart_toy</span><p></p>`;
  chatLi.innerHTML = chatContent;
  chatLi.querySelector("p").textContent = message;
  return chatLi;
}

const generateResponse = async (chatElement) => {
  const messageElement = chatElement.querySelector("p");

  const requestOptions = {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ 
      contents: [{ 
        role: "user", 
        parts: [{ text: userMessage }] 
      }] 
    }),
  }

  try {
    const response = await fetch(API_URL, requestOptions);
    const data = await response.json();
    if (!response.ok) throw new Error(data.error.message);
    
    messageElement.textContent = data.candidates[0].content.parts[0].text.replace(/\*\*(.*?)\*\*/g, '$1');
  } catch (error) {
    messageElement.classList.add("error");
    messageElement.textContent = error.message;
  } finally {
    chatbox.scrollTo(0, chatbox.scrollHeight);
  }
}

const handleChat = () => {
  userMessage = chatInput.value.trim(); 
  if (!userMessage) return;

  chatInput.value = "";
  chatInput.style.height = `${inputInitHeight}px`;

  chatbox.appendChild(createChatLi(userMessage, "outgoing"));
  chatbox.scrollTo(0, chatbox.scrollHeight);

  setTimeout(() => {
    const incomingChatLi = createChatLi("Thinking...", "incoming");
    chatbox.appendChild(incomingChatLi);
    chatbox.scrollTo(0, chatbox.scrollHeight);
    generateResponse(incomingChatLi);
  }, 600);
}

// Handle speech input from microphone
micBtn.addEventListener("click", () => {
  recognition.start(); // Start listening when mic is clicked
  micBtn.classList.add("listening"); // Optional: Add visual cue that mic is active
});

recognition.addEventListener("result", (event) => {
  const transcript = event.results[0][0].transcript;
  chatInput.value = transcript; // Insert speech result into chat input
  recognition.stop(); // Stop after receiving the result
  micBtn.classList.remove("listening");
});

recognition.addEventListener("end", () => {
  if (micBtn.classList.contains("listening")) {
    micBtn.classList.remove("listening"); // Remove visual cue if recognition ends
  }
});

chatInput.addEventListener("input", () => {
  chatInput.style.height = `${inputInitHeight}px`;
  chatInput.style.height = `${chatInput.scrollHeight}px`;
});

chatInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey && window.innerWidth > 800) {
    e.preventDefault();
    handleChat();
  }
});

sendChatBtn.addEventListener("click", handleChat);
closeBtn.addEventListener("click", () => document.body.classList.remove("show-chatbot"));
chatbotToggler.addEventListener("click", () => document.body.classList.toggle("show-chatbot"));

chatbox.addEventListener('scroll', () => {
  const scrollTop = chatbox.scrollTop; // Current scroll position
  const scrollHeight = chatbox.scrollHeight; // Total height of the chatbox content
  const clientHeight = chatbox.clientHeight; // Height of the visible chatbox area

  // Ensure copyright stays visible when scrolling
  if (scrollTop + clientHeight >= scrollHeight - 10) {
    copyright.style.opacity = '1'; // Show copyright text
  } else {
    copyright.style.opacity = '1'; // Keep copyright visible at all times
  }
});

// Adjust chatbox height to not overlap with the input area
const adjustChatboxHeight = () => {
  const inputHeight = 55; // Set fixed height of the input area
  const copyrightHeight = 30; // Estimated height of the copyright text (adjust as needed)
  const additionalHeight = 100; // Additional height you want to add for the chatbox

  chatbox.style.maxHeight = `calc(100vh - ${inputHeight + copyrightHeight + 20}px)`; // Set max-height dynamically
  chatbox.style.overflowY = 'auto'; // Allow scrolling when the content exceeds the height
};

// Call the function to set the initial chatbox height
adjustChatboxHeight();

// Recalculate height on window resize
window.addEventListener('resize', adjustChatboxHeight);